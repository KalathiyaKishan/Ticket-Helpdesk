import React, { useState } from "react";

const Messages = ({ onSend }) => {
    const [text, setText] = useState("");

    const handleSend = () => {
        if (text.trim() === "") return;
        if (onSend) onSend(text);
        setText("");
    };

    return (
        <div className="composer-container">
            <input
                className="full-width-input"
                value={text}
                onChange={(e) => setText(e.target.value)}
                placeholder="Write your message..."
                onKeyDown={(e) => e.key === 'Enter' && handleSend()}
            />
            <button className="send-btn-right" onClick={handleSend}>
                Send
            </button>
        </div>
    );
};

export default Messages;