import React, { useState } from "react";

const MessageComposer = ({ onSend }) => {
  const [text, setText] = useState("");

  const handleSend = () => {
    if (text.trim() === "") return;
    onSend(text);
    setText("");
  };

  return (
    <>
      <input
        className="full-width-input"
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="Write your message..."
        onKeyDown={(e) => e.key === 'Enter' && handleSend()}
      />
      <button className="send-btn-right" onClick={handleSend}>
        Send
      </button>
    </>
  );
};

export default MessageComposer;