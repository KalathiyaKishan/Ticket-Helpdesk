import React from "react";

const TicketList = ({ tickets, onSelect, selected }) => {
  return (
    <div className="ticket-list">
      <h3>Tickets</h3>
      {tickets.map((t) => (
        <div
          key={t.id}
          className={selected && selected.id === t.id ? "ticket-card active" : "ticket-card"}
          onClick={() => onSelect(t)}
        >
          <h4>{t.title}</h4>
          <p>Status: {t.status}</p>
        </div>
      ))}
    </div>
  );
};

export default TicketList;