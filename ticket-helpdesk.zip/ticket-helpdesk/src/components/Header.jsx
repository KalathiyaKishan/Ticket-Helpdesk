import React from "react";

const Header = () => {
  return (
    <header style={{ padding: "15px", background: "#1f2937", color: "white" }}>
      <h1 style={{ margin: 0 }}>Helpdesk Ticketing</h1>
    </header>
  );
};

export default Header;