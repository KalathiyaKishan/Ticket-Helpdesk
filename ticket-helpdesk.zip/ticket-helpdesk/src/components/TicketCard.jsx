import React from "react";

const TicketCard = ({ ticket, onClick }) => {
    return (
        <div onClick={onClick} style={{
                border: "1px solid #ccc",
                padding: "10px",
                margin: "10px",
                cursor: "pointer",
            }}>

            <h4>{ticket.title}</h4>
            <small>Status: {ticket.status}</small>
        </div>
    );
};

export default TicketCard;