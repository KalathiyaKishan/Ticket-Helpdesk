import React, { useState } from "react";
import MessageComposer from "./MessageComposer";

const TicketDetail = ({ ticket }) => {
  const [activeTab, setActiveTab] = useState("public");

  if (!ticket) return <div className="detail-pane empty">Select a ticket to start</div>;

  const displayMessages = ticket.messages?.filter(m => {
    const msgType = m.type || "public";
    return msgType === activeTab;
  }) || [];

  return (
    <div className="detail-pane">
      <div className="detail-header">
        <h2>{ticket.title}</h2>
        <span className={`status-pill ${ticket.status.replace(/\s+/g, '')}`}>
          {ticket.status}
        </span>
      </div>

      <div className="tabs-bar">
        <button className={activeTab === "public" ? "active" : ""} onClick={() => setActiveTab("public")}>
          Public Chat
        </button>
        <button className={activeTab === "private" ? "active" : ""} onClick={() => setActiveTab("private")}>
          Internal Note
        </button>
      </div>

      <div className="chat-content">
        {displayMessages.length > 0 ? (
          displayMessages.map((msg) => (
            <div key={msg.id} className={`message-bubble ${activeTab}`}>
              {msg.text}
            </div>
          ))
        ) : (
          <p className="no-msg">No {activeTab === "public" ? "public messages" : "internal notes"} yet.</p>
        )}
      </div>

      <div className="composer-container">
        <MessageComposer onSend={(text) => console.log("New message:", text)} />
      </div>
    </div>
  );
};

export default TicketDetail;