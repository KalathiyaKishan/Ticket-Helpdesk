import React, { useState, useEffect } from "react";
import "./index.css";
import Header from "./components/Header";
import TicketList from "./components/TicketList";
import TicketDetail from "./components/TicketDetail";

export default function App() {
  const [tickets, setTickets] = useState([]);
  const [selected, setSelected] = useState(null);

  useEffect(() => {
    fetch("/db.json")
      .then((res) => res.json())
      .then((data) => {
        setTickets(data.tickets);
        if (data.tickets.length > 0) setSelected(data.tickets[0]);
      })
      .catch((err) => console.log("Error:", err));
  }, []);

return (
  <div className="app-container">
    <Header />
    <div className="content-body">
      <TicketList
        tickets={tickets}
        onSelect={setSelected}
        selected={selected}
      />
      <TicketDetail ticket={selected} />
    </div>
  </div>
);
}